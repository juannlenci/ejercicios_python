#arboles.py

import csv
from pprint import pprint

arboles =[]
especies =[]
ejemplares = {}

def leer_parque(nombre_archivo, parque):
    arboles =[]
    #El encoding="utf8" lo agrego para evitar "UnicodeDecodeError"
    with open (nombre_archivo, encoding="utf8") as f:
        rows = csv.reader(f)
        header = next(rows)
        for n_fila, fila in enumerate(rows, start=1):
            record = dict(zip(header, fila))
            try:
                if (record["espacio_ve"])==parque:
                    arboles.append(record)
            except ValueError:
                print(f'Fila {n_fila}: No pude interpretar: {fila}')
    return arboles
    
def especies(lista_arboles):
    especies_totales =[]
    especie=set(especies_totales)
    for n_fila, fila in enumerate(lista_arboles, start=0):
        especie_aux=(lista_arboles[n_fila]["nombre_com"])
        especie.add(especie_aux)
    return especie
    
def contar_ejemplares(lista_arboles):
    ejemplar =[]
    especie = especies(lista_arboles)
    
    #Genero lista de especies
    ejemplar = list(especie)
    #Genero lista de ceros que voy a usar como contadores    
    cont = [0]*(len(ejemplar))
    #Genero diccionario
    ejemplares = dict(zip(ejemplar, cont))

    for n_fila, fila in enumerate(lista_arboles, start=0):
        #la magia
        ejemplares[(lista_arboles[n_fila]["nombre_com"])] += 1
    return ejemplares

def obtener_alturas(lista_arboles, especie):
    alturas =[]
    for n_fila, fila in enumerate(lista_arboles, start=0):
        if (lista_arboles[n_fila]["nombre_com"]) == especie:
            alturas.append(float(lista_arboles[n_fila]["altura_tot"]))
                           
    return alturas

def obtener_inclinaciones(lista_arboles, especie):
    inclinaciones =[]
    for n_fila, fila in enumerate(lista_arboles, start=0):
        if (lista_arboles[n_fila]["nombre_com"]) == especie:
            inclinaciones.append(int(lista_arboles[n_fila]["inclinacio"]))
                           
    return inclinaciones

def especimen_mas_inclinado(lista_arboles):
    esp_inclinada = []
    
    especie = list(especies(lista_arboles))
    
    cont=0
    
    for n_fila, fila in enumerate(especie, start=0):
        inclinaciones = obtener_inclinaciones(lista_arboles,especie[n_fila])
        if (max(inclinaciones) > cont):
            name = especie[n_fila]
            cont = max(inclinaciones)
    
    esp_inclinada = [name,cont]
    
    return esp_inclinada

def especie_promedio_mas_inclinada(lista_arboles):
    prom_inclinada = []
    
    especie = list(especies(lista_arboles))
    
    cont=0
    
    for n_fila, fila in enumerate(especie, start=0):
        inclinaciones = obtener_inclinaciones(lista_arboles,especie[n_fila])
        promedio = (sum(inclinaciones))/(len(inclinaciones))
        if (promedio > cont):
            name = especie[n_fila]
            cont = promedio
    
    prom_inclinada = [name,cont]
    return prom_inclinada

    
#----------------------------Leer Archivo--------------------------------------
#Se pasa Archivo y parque, devuelve lista de arboles en el parque 
#con todas sus caracteristicas
parque = "ANDES, LOS"
arboles = leer_parque ("../Data/arbolado-en-espacios-verdes.csv",parque)

#pprint(arboles)
print(f"En el parque {parque} hay un total de {len(arboles)} arboles")
#------------------------------------------------------------------------------

#----------------------------Especies------------------------------------------
#Se pasa listado de arboles del parque y devueve cnjunto de especies
especie = especies(arboles)

#pprint(especie)
print(f"En el parque {parque} hay un total de {len(especie)} especies")
#------------------------------------------------------------------------------

#----------------------------Ejemplares----------------------------------------
#Se pasa listado de arboles del parque y devuelve diccionario con los
#ejemplares como claves y la cantidad como valores
ejemplares = contar_ejemplares(arboles)
#**********************Imprimir Ejemplares*******************************
#(Revisar para hacer con most_common)
ejemplares_list = list(zip(ejemplares.values(), ejemplares.keys()))
ejemplares_list.sort(reverse=True)
print(f"En el parque {parque} las Especies mas comunes son:")
print(f"Cant.   Especie")

#pprint(ejemplares_list)
for n_fila, fila in enumerate(ejemplares_list, start=0):
    print(ejemplares_list[n_fila])
    if n_fila == 5-1:
        break
#------------------------------------------------------------------------------

#----------------------------Alturas-------------------------------------------
#Se pasa listado de arboles del parque y especie y devuelve lista con todas
#las alturas.
arbol_altura = "Jacarandá" 
alturas = obtener_alturas(arboles,arbol_altura)
#pprint(alturas)
print (f"En el parque {parque} la altura maxima de {arbol_altura} es de {max(alturas)} mts")
promedio = (sum(alturas))/(len(alturas))
print (f"En el parque {parque} la altura promedio de {arbol_altura} es de {promedio:0.2f} mts")
#------------------------------------------------------------------------------

#----------------------------Inclinaciones-------------------------------------
#Se pasa listado de arboles del parque y especie y devuelve lista con todas
#las alturas.
arbol_inclinacion = "Jacarandá" 
inclinaciones = obtener_inclinaciones(arboles,arbol_inclinacion)
#pprint(inclinaciones)
print (f"En el parque {parque} la inclinacion maxima de {arbol_inclinacion} es de {max(inclinaciones)}°")
#------------------------------------------------------------------------------

#----------------------------Especie mas inclinada-------------------------------------
#Se pasa listado de arboles del parque y especie y devuelve lsita con nombre e 
#inclinacion maxima de especie.
esp_inclinada = especimen_mas_inclinado(arboles)
print (f"En el parque {parque} la inclinacion maxima es de la especie {esp_inclinada[0]} con {esp_inclinada[1]}°")

#------------------------Especie mas inclinada promedio---------------------------------
#Se pasa listado de arboles del parque y especie y devuelve lsita con nombre e 
#inclinacion promedio maxima de especie.
prom_inclinada = especie_promedio_mas_inclinada(arboles)
print (f"En el parque {parque} la inclinacion promedio maxima es de la especie {prom_inclinada[0]} con {prom_inclinada[1]}°")

